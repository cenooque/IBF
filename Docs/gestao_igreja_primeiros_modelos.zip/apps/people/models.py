from django.db import models
from django.db.models import Q


class Pessoa(models.Model):
    class Sexo(models.TextChoices):
        MASCULINO = "M", "Masculino"
        FEMININO = "F", "Feminino"

    class EstadoCivil(models.TextChoices):
        SOLTEIRO = "SOLTEIRO", "Solteiro(a)"
        CASADO = "CASADO", "Casado(a)"
        DIVORCIADO = "DIVORCIADO", "Divorciado(a)"
        SEPARADO = "SEPARADO", "Separado(a)"
        VIUVO = "VIUVO", "Viúvo(a)"
        OUTRO = "OUTRO", "Outro"

    class SituacaoIgreja(models.TextChoices):
        IBF = "IBF", "Membro da IBF"
        OUTRA = "OUTRA", "Membro de outra igreja"
        NAO_FREQUENTA = "NAO_FREQUENTA", "Não frequenta igreja"

    nome_completo = models.CharField("Nome completo", max_length=180)
    sexo = models.CharField("Sexo", max_length=1, choices=Sexo.choices)
    endereco = models.CharField("Endereço", max_length=180, blank=True)
    bairro = models.CharField("Bairro", max_length=100, blank=True)
    cidade = models.CharField("Cidade", max_length=100, blank=True)
    estado = models.CharField("Estado (UF)", max_length=2, blank=True)
    cep = models.CharField("CEP", max_length=9, blank=True)
    telefone = models.CharField("Telefone", max_length=25, blank=True)
    email = models.EmailField("E-mail", blank=True)
    data_nascimento = models.DateField("Data de nascimento", null=True, blank=True)
    data_batismo = models.DateField("Data de batismo", null=True, blank=True)
    estado_civil = models.CharField(
        "Estado civil", max_length=15,
        choices=EstadoCivil.choices, default=EstadoCivil.SOLTEIRO
    )
    situacao_igreja = models.CharField(
        "Vínculo com a igreja", max_length=15,
        choices=SituacaoIgreja.choices,
        default=SituacaoIgreja.NAO_FREQUENTA
    )
    observacoes = models.TextField("Observações", blank=True)
    ativo = models.BooleanField("Cadastro ativo", default=True)
    criado_em = models.DateTimeField("Criado em", auto_now_add=True)
    atualizado_em = models.DateTimeField("Atualizado em", auto_now=True)

    class Meta:
        ordering = ["nome_completo"]
        verbose_name = "Pessoa"
        verbose_name_plural = "Pessoas"
        indexes = [
            models.Index(fields=["nome_completo"]),
            models.Index(fields=["situacao_igreja"]),
        ]

    def __str__(self):
        return self.nome_completo


class RelacionamentoFamiliar(models.Model):
    class Tipo(models.TextChoices):
        CONJUGE = "CONJUGE", "Cônjuge"
        FILHO = "FILHO", "Filho(a)"

    pessoa_titular = models.ForeignKey(
        Pessoa, on_delete=models.PROTECT, related_name="relacoes_familiares",
        verbose_name="Pessoa de referência"
    )
    familiar = models.ForeignKey(
        Pessoa, on_delete=models.PROTECT, related_name="vinculos_familiares",
        verbose_name="Familiar"
    )
    tipo = models.CharField("Parentesco", max_length=10, choices=Tipo.choices)
    data_casamento = models.DateField("Data de casamento", null=True, blank=True)
    observacoes = models.CharField("Observações", max_length=255, blank=True)
    criado_em = models.DateTimeField("Criado em", auto_now_add=True)

    class Meta:
        verbose_name = "Relacionamento familiar"
        verbose_name_plural = "Relacionamentos familiares"
        constraints = [
            models.UniqueConstraint(
                fields=["pessoa_titular", "familiar"],
                name="uq_relacao_familiar_pessoas"
            ),
            models.UniqueConstraint(
                fields=["pessoa_titular"],
                condition=Q(tipo="CONJUGE"),
                name="uq_um_conjuge_por_titular"
            ),
            models.CheckConstraint(
                condition=~Q(pessoa_titular=models.F("familiar")),
                name="ck_pessoa_nao_pode_ser_proprio_familiar"
            ),
        ]

    def __str__(self):
        return f"{self.pessoa_titular} - {self.get_tipo_display()} - {self.familiar}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.pessoa_titular_id and self.familiar_id and self.pessoa_titular_id == self.familiar_id:
            raise ValidationError("Uma pessoa não pode ser vinculada a si mesma.")
        if self.tipo != self.Tipo.CONJUGE and self.data_casamento:
            raise ValidationError("A data de casamento só pode ser informada para o vínculo de cônjuge.")
