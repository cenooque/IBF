from django.contrib import admin
from .models import Pessoa, RelacionamentoFamiliar


class RelacionamentoFamiliarInline(admin.TabularInline):
    model = RelacionamentoFamiliar
    fk_name = "pessoa_titular"
    extra = 0
    autocomplete_fields = ["familiar"]


@admin.register(Pessoa)
class PessoaAdmin(admin.ModelAdmin):
    list_display = (
        "nome_completo", "sexo", "situacao_igreja",
        "telefone", "cidade", "ativo"
    )
    list_filter = ("sexo", "estado_civil", "situacao_igreja", "ativo")
    search_fields = ("nome_completo", "telefone", "email", "cidade")
    ordering = ("nome_completo",)
    inlines = [RelacionamentoFamiliarInline]
    fieldsets = (
        ("Dados pessoais", {
            "fields": (
                "nome_completo", "sexo", "data_nascimento", "data_batismo",
                "estado_civil", "situacao_igreja"
            )
        }),
        ("Contato e endereço", {
            "fields": (
                "telefone", "email", "endereco", "bairro",
                "cidade", "estado", "cep"
            )
        }),
        ("Outras informações", {"fields": ("observacoes", "ativo")}),
    )


@admin.register(RelacionamentoFamiliar)
class RelacionamentoFamiliarAdmin(admin.ModelAdmin):
    list_display = ("pessoa_titular", "tipo", "familiar", "data_casamento")
    list_filter = ("tipo",)
    search_fields = (
        "pessoa_titular__nome_completo", "familiar__nome_completo"
    )
    autocomplete_fields = ("pessoa_titular", "familiar")
