from django.contrib import admin
from .models import ContaFinanceira, CentroCusto, PlanoContas


@admin.register(ContaFinanceira)
class ContaFinanceiraAdmin(admin.ModelAdmin):
    list_display = (
        "codigo", "nome", "tipo", "instituicao",
        "saldo_inicial", "centro_custo", "ativa"
    )
    list_filter = ("tipo", "ativa")
    search_fields = ("codigo", "nome", "instituicao", "numero_conta")
    autocomplete_fields = ("centro_custo",)


@admin.register(CentroCusto)
class CentroCustoAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nome", "centro_pai", "ativo")
    list_filter = ("ativo",)
    search_fields = ("codigo", "nome")
    autocomplete_fields = ("centro_pai",)


@admin.register(PlanoContas)
class PlanoContasAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nome", "natureza", "tipo", "conta_pai", "ativo")
    list_filter = ("natureza", "tipo", "ativo")
    search_fields = ("codigo", "nome")
    autocomplete_fields = ("conta_pai",)
