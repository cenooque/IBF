from django.db import models


class CentroCusto(models.Model):
    codigo = models.CharField("Código", max_length=20, unique=True)
    nome = models.CharField("Nome", max_length=120)
    descricao = models.TextField("Descrição", blank=True)
    centro_pai = models.ForeignKey(
        "self", on_delete=models.PROTECT, null=True, blank=True,
        related_name="subcentros", verbose_name="Centro de custo superior"
    )
    ativo = models.BooleanField("Ativo", default=True)
    criado_em = models.DateTimeField("Criado em", auto_now_add=True)

    class Meta:
        ordering = ["codigo"]
        verbose_name = "Centro de custo"
        verbose_name_plural = "Centros de custo"

    def __str__(self):
        return f"{self.codigo} - {self.nome}"


class ContaFinanceira(models.Model):
    class Tipo(models.TextChoices):
        CAIXA = "CAIXA", "Caixa geral"
        BANCO = "BANCO", "Conta bancária"
        CAIXA_DEPARTAMENTO = "CAIXA_DEP", "Caixa de departamento"
        FUNDO = "FUNDO", "Fundo específico"

    codigo = models.CharField("Código", max_length=20, unique=True)
    nome = models.CharField("Nome da conta", max_length=120)
    tipo = models.CharField("Tipo", max_length=12, choices=Tipo.choices)
    instituicao = models.CharField("Banco/instituição", max_length=100, blank=True)
    agencia = models.CharField("Agência", max_length=20, blank=True)
    numero_conta = models.CharField("Número da conta", max_length=30, blank=True)
    chave_pix = models.CharField("Chave PIX", max_length=120, blank=True)
    centro_custo = models.ForeignKey(
        CentroCusto, on_delete=models.PROTECT, null=True, blank=True,
        related_name="contas_financeiras", verbose_name="Centro de custo responsável"
    )
    saldo_inicial = models.DecimalField(
        "Saldo inicial", max_digits=14, decimal_places=2, default=0
    )
    data_saldo_inicial = models.DateField("Data do saldo inicial", null=True, blank=True)
    observacoes = models.TextField("Observações", blank=True)
    ativa = models.BooleanField("Conta ativa", default=True)
    criada_em = models.DateTimeField("Criada em", auto_now_add=True)

    class Meta:
        ordering = ["codigo"]
        verbose_name = "Conta financeira"
        verbose_name_plural = "Contas financeiras"
        indexes = [models.Index(fields=["tipo", "ativa"])]
        permissions = [
            ("view_relatorio_financeiro", "Pode acessar a área de relatórios financeiros"),
            ("view_relatorio_fluxo_caixa", "Pode visualizar relatório de fluxo de caixa"),
            ("view_relatorio_prestacao_contas", "Pode visualizar prestação de contas"),
            ("view_relatorio_receitas_despesas", "Pode visualizar relatório de receitas e despesas"),
        ]

    def __str__(self):
        return f"{self.codigo} - {self.nome}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.tipo == self.Tipo.BANCO and not self.instituicao:
            raise ValidationError({"instituicao": "Informe o banco ou instituição da conta bancária."})


class PlanoContas(models.Model):
    class Natureza(models.TextChoices):
        RECEITA = "RECEITA", "Receita"
        DESPESA = "DESPESA", "Despesa"

    class Tipo(models.TextChoices):
        SINTETICA = "SINTETICA", "Sintética (agrupadora)"
        ANALITICA = "ANALITICA", "Analítica (recebe lançamentos)"

    codigo = models.CharField("Código", max_length=30, unique=True)
    nome = models.CharField("Descrição", max_length=150)
    natureza = models.CharField("Natureza", max_length=8, choices=Natureza.choices)
    tipo = models.CharField(
        "Tipo de conta", max_length=10, choices=Tipo.choices,
        default=Tipo.ANALITICA
    )
    conta_pai = models.ForeignKey(
        "self", on_delete=models.PROTECT, null=True, blank=True,
        related_name="subcontas", verbose_name="Conta superior"
    )
    ativo = models.BooleanField("Ativo", default=True)
    criado_em = models.DateTimeField("Criado em", auto_now_add=True)

    class Meta:
        ordering = ["codigo"]
        verbose_name = "Plano de contas"
        verbose_name_plural = "Planos de contas"
        indexes = [models.Index(fields=["natureza", "ativo"])]

    def __str__(self):
        return f"{self.codigo} - {self.nome}"

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.conta_pai_id:
            if self.conta_pai.natureza != self.natureza:
                raise ValidationError({"conta_pai": "A conta superior deve ter a mesma natureza."})
            if self.conta_pai_id == self.pk:
                raise ValidationError({"conta_pai": "Uma conta não pode ser superior a si mesma."})
